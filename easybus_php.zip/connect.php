<?php
	$servername = "localhost";
	$user = "id4149966_alihaidar";
	$pass = "ali..1997";
	$dbName="id4149966_easy_bus";
	$conn=mysqli_connect($servername,$user,$pass,$dbName);
	?>