<?php
	echo "Connected!";
	?>